// formapp.js

var txtStudentId = document.getElementById("studentId");
txtStudentId.value = "000-11-0001";