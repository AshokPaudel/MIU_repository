// app_fnex.js 

f();
// g();

function f() {
    console.log("called f");
}

var g = function() {
    console.log("called g");
}

g();